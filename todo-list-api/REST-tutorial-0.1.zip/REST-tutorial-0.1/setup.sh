python virtualenv.py flask
flask/bin/pip install -r requirements.txt
